using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BackendService.Data;
using BackendService.DTOs;
using BackendService.Models;
using BackendService.Repos;

namespace BackendService.Services
{
    public class DonationService
    {
        private readonly IDonationRepo _donationRepo;
        private readonly IDonorRepo _donorRepo;
        private readonly IPopulationTypeRepo _populationTypeRepo;
        private readonly IUserRepo _userRepo;
        private readonly IRedemptionRepo _redemptionRepo;
        private readonly IUnitOfWork _unitOfWork;

        public DonationService(
            IDonationRepo donationRepo,
            IDonorRepo donorRepo,
            IPopulationTypeRepo populationTypeRepo,
            IUserRepo userRepo,
            IRedemptionRepo redemptionRepo,
            IUnitOfWork unitOfWork)
        {
            _donationRepo = donationRepo;
            _donorRepo = donorRepo;
            _populationTypeRepo = populationTypeRepo;
            _userRepo = userRepo;
            _redemptionRepo = redemptionRepo;
            _unitOfWork = unitOfWork;
        }

        public async Task<int> CreateDonationAsync(
            int userId,
            CreateDonationDto dto
        )
        {
            var user = await _userRepo.GetByIdAsync(userId);

            if (user == null || !user.IsActive || user.UserType != "DONOR")
            {
                throw new UnauthorizedAccessException(
                    "User is not an active donor.");
            }

            var donor = await _donorRepo.GetByUserIdAsync(userId);

            if (donor == null)
            {
                throw new InvalidOperationException(
                    "Donor profile not found.");
            }

            var populationType = await _populationTypeRepo
                .GetByIdAsync(dto.PopulationTypeId);

            if (populationType == null || !populationType.IsActive)
            {
                throw new ArgumentException(
                    "Population type is invalid or inactive.");
            }

            // Validate business rules
            if (dto.TotalAmount <= 0 ||
                dto.MaxAmountPerRecipient <= 0)
            {
                throw new ArgumentException(
                    "Donation amounts must be positive.");
            }

            var now = DateTime.UtcNow;

            if (dto.ExpirationDate.ToUniversalTime() <= now)
            {
                throw new ArgumentException(
                    "Expiration date must be in the future.");
            }

            // Create Donation
            var donation = new Donation
            {
                DonorId = donor.Id,
                PopulationTypeId = dto.PopulationTypeId,
                TotalAmount = dto.TotalAmount,
                RemainingAmount = dto.TotalAmount,
                MaxAmountPerRecipient = dto.MaxAmountPerRecipient,
                Description = dto.Description,
                CreatedAt = now,
                ExpirationDate = dto.ExpirationDate.ToUniversalTime(),
                Status = "ACTIVE"
            };

            await _donationRepo.AddAsync(donation);

            await _unitOfWork.SaveChangesAsync();

            return donation.Id;
        }

        public async Task<List<DonationResponseDto>> GetMyDonationsAsync(int userId)
        {
            var donor = await _donorRepo.GetByUserIdAsync(userId);

            if (donor == null)
            {
                throw new InvalidOperationException("Donor profile not found.");
            }

            var donations = await _donationRepo.GetByDonorIdAsync(donor.Id);

            return donations.Select(d => new DonationResponseDto
            {
                Id = d.Id,
                PopulationTypeId = d.PopulationTypeId,
                TotalAmount = d.TotalAmount,
                RemainingAmount = d.RemainingAmount,
                MaxAmountPerRecipient = d.MaxAmountPerRecipient,
                Description = d.Description,
                CreatedAt = d.CreatedAt,
                ExpirationDate = d.ExpirationDate,
                Status = d.Status
            }).ToList();
        }

        public async Task UpdateDonationAsync(
            int userId,
            int donationId,
            UpdateDonationDto dto)
        {
            // Find the authenticated donor
            var donor = await _donorRepo.GetByUserIdAsync(userId);

            if (donor == null)
            {
                throw new UnauthorizedAccessException(
                    "Donor profile not found.");
            }

            // Find the donation
            var donation = await _donationRepo.GetByIdAsync(donationId);

            if (donation == null)
            {
                throw new KeyNotFoundException(
                    "Donation not found.");
            }

            // Verify ownership
            if (donation.DonorId != donor.Id)
            {
                throw new UnauthorizedAccessException(
                    "You cannot edit this donation.");
            }

            // Only active and non-expired donations can be edited
            if (donation.Status != "ACTIVE" ||
                donation.ExpirationDate <= DateTime.UtcNow)
            {
                throw new InvalidOperationException(
                    "Donation is not active or has expired.");
            }

            // Validate input
            if (dto.TotalAmount <= 0 ||
                dto.MaxAmountPerRecipient <= 0)
            {
                throw new ArgumentException(
                    "Amounts must be positive.");
            }

            if (dto.ExpirationDate.ToUniversalTime() <= DateTime.UtcNow)
            {
                throw new ArgumentException(
                    "Expiration date must be in the future.");
            }

            // Calculate the amount already redeemed
            decimal redeemedAmount =
                donation.TotalAmount - donation.RemainingAmount;

            if (dto.TotalAmount < redeemedAmount)
            {
                throw new InvalidOperationException(
                    "Total amount cannot be lower than already redeemed amount.");
            }

            // Update the donation
            donation.TotalAmount = dto.TotalAmount;
            donation.RemainingAmount = dto.TotalAmount - redeemedAmount;
            donation.MaxAmountPerRecipient = dto.MaxAmountPerRecipient;
            donation.Description = dto.Description;
            donation.ExpirationDate = dto.ExpirationDate.ToUniversalTime();

            await _unitOfWork.SaveChangesAsync();
        }

        public async Task CancelDonationAsync(int userId, int donationId)
        {
            // Find authenticated donor
            var donor = await _donorRepo.GetByUserIdAsync(userId);

            if (donor == null)
            {
                throw new UnauthorizedAccessException(
                    "Donor profile not found.");
            }

            // Find donation
            var donation = await _donationRepo.GetByIdAsync(donationId);

            if (donation == null)
            {
                throw new KeyNotFoundException(
                    "Donation not found.");
            }

            // Verify ownership
            if (donation.DonorId != donor.Id)
            {
                throw new UnauthorizedAccessException(
                    "You cannot cancel this donation.");
            }

            // Validate status
            if (donation.Status != "ACTIVE")
            {
                throw new InvalidOperationException(
                    "Only active donations can be cancelled.");
            }

            if (donation.ExpirationDate <= DateTime.UtcNow)
            {
                throw new InvalidOperationException(
                    "Donation has already expired.");
            }

            // Find pending redemptions
            var pendingRedemptions = await _redemptionRepo
                .GetPendingByDonationIdAsync(donationId);

            // Cancel donation
            donation.Status = "CANCELLED";

            // Cancel pending redemptions
            foreach (var redemption in pendingRedemptions)
            {
                redemption.Status = "CANCELLED";
            }

            // Save all changes together
            await _unitOfWork.SaveChangesAsync();
        }

    }
}